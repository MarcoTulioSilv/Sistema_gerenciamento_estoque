import os
import customtkinter as ctk
from datetime import datetime
from Modulo_04_notificacoes.scheduler import NotificacaoScheduler
from gui.telas.t01_login import TelaLogin
from gui.telas.placeholder import TelaPlaceholder
from tkinter import messagebox
from Modulo_01_autenticacao import SessionManager
from gui.telas.t02_inicio import TelaInicio
from gui.telas.t03_produtos import TelaProdutos
from gui.telas.t21_troca_senha import TelaTrocaSenha
from gui.telas.t05_novo_produto import TelaNovoProduto
from gui.telas.t07_entrada_manual import TelaEntradaManual
from gui.telas.t08_importar_nfe import TelaImportarNFe
from gui.telas.t07c_entrada_danfe import TelaEntradaDANFE
from gui.telas.t09_retirada import TelaRetirada
from gui.telas.t10_posicao_estoque import TelaPosicaoEstoque
from gui.telas.t22_dashboard import TelaDashboard
from gui.telas.t11_relatorios import TelaCentralRelatorios
from gui.telas.t12_agendamento import TelaAgendamento
from gui.telas.t13_estoque_minimo import TelaEstoqueMinimo

# tema global
ctk.set_appearance_mode("light")
ctk.set_default_color_theme("blue")

COR_AZUL      = "#1F4E79"
COR_AZUL_M    = "#2E75B6"
COR_SIDEBAR   = "#1F4E79"
COR_SIDEBAR_H = "#2E75B6"   # hover
COR_SIDEBAR_A = "#2E75B6"   # ativo
COR_CINZA_E   = "#F2F1ED"
COR_TEXTO     = "#3d3d3a"
COR_VERMELHO  = "#A32D2D"

class SCEApp(ctk.CTk):
    # Janela raiz do sistema, gerencia login e navegação entre telas
    def __init__(self):
        super().__init__()

        self.title("Sistema de Controle de Estoque - Centro de Uronefrologia")
        self.geometry("1100x600")
        self.minsize(900, 600)
        self.configure(fg_color=COR_CINZA_E)

        # Estado dee sessão
        self.usuario_logado = None #objeto do usuário logado

        #Inicializa o scheduler de notificações
        self._scheduler= NotificacaoScheduler()
        self._scheduler.iniciar()
        self.session_timer = None

        #exibe tela de login na inicialização
        self._monstrar_login()

#---- login/ logout ----
    def _monstrar_login(self):
        """limpa a janela e exibe a tela de login"""        
        for widget in self.winfo_children():
            widget.destroy()
        TelaLogin(self, on_login_success=self._on_login_success).pack(fill="both", expand=True)
    
    def _on_login_success(self, usuario):
        """callback chamaado pelo mod-01 apos autenticação bem sucedida"""
        self.usuario_logado = usuario
        SessionManager.iniciar_sessao(usuario)
        self._iniciar_timer_sessao()
        self._construir_layout_principal()

    def logout(self):
        """encerra sessão e volta para tela de login"""
        if self.session_timer:
            self.after_cancel(self.session_timer)
        SessionManager.encerrar_sessao()
        self.usuario_logado = None
        self._monstrar_login()

#----- sessão ---------------------------------------------------------------------------------
    def _iniciar_timer_sessao(self):
        
        timeout_min = int(os.getenv("SESSION_TIMEOUT_MIN", 30))
        timeout_ms = timeout_min * 60 * 1000
        if self.session_timer:
            self.after_cancel(self.session_timer)
        self.session_timer = self.after(timeout_ms, self._sessao_expirada)
    
    def resetar_timer_sessao(self):
        """chamado por telas para resetar o timer a cada interação do usuário"""
        self._iniciar_timer_sessao()
    
    def _sessao_expirada(self):
       
        messagebox.showinfo("Sessão Expirada", "Sua sessão expirou por inatividade. Faça login novamente.")
        self.logout()
        """ tecnico deve ter tempo de sessão maior, dash board não deve expirar """

#---- layout principal--------------------------------------------------------------------------------------

    def _construir_layout_principal(self):
        """Monta a estrutura de 3 faixas, titlebar, conteudo(sidebar + main)"""
        for w in self.winfo_children():
            w.destroy() 
        #titlebar
        self._titlebar = TitleBar(self, usuario=self.usuario_logado, )
        self._titlebar.pack(fill="x")

        #corpo: sidebar + main
        corpo= ctk.CTkFrame(self, fg_color=COR_CINZA_E)
        corpo.pack(fill="both", expand=True)
        corpo.grid_columnconfigure(1, weight=1)
        corpo.grid_rowconfigure(0, weight=1)

        self._sidebar = Sidebar(corpo, usuario=self.usuario_logado, on_navigate=self._navegar,on_logout=self.logout)
        self._sidebar.grid(row=0, column=0, sticky="nsw")

        self._area_conteudo = ctk.CTkFrame(corpo, fg_color=COR_CINZA_E)
        self._area_conteudo.grid(row=0, column=1, sticky="nsew", padx=0, pady=0)

        #exibe tela inicial por padrão
        self._navegar("inicio")

    def _navegar(self, destino: str):
        """troca o conteudo da area principal pela tela indicada """
        self.resetar_timer_sessao()
        for w in self._area_conteudo.winfo_children():
            w.destroy()
        
        tela = self._resolver_tela(destino)
        if tela:
            tela.pack(fill="both", expand=True)
    
    def _resolver_tela(self, destino: str, extra=None):
        """mapeia o indicador de destino para a classe de tela correspondente"""
        nav= self._on_navigate_com_extra
        # sprint 1: telas reia de autenticação plugadas.
        # telas reais colocadas aqui nas proximas sprints
        if destino=="inicio":
            return TelaInicio(self._area_conteudo, usuario=self.usuario_logado, on_navigate= nav)
        if destino=="troca_senha":
            return TelaTrocaSenha(self._area_conteudo, usuario=self.usuario_logado, on_navigate= nav)
        #______ Sprint 2A_ MOD-02 cadastros
        if destino=="produtos":
            return TelaProdutos(self._area_conteudo, usuario= self.usuario_logado, on_navigate= nav)
        if destino in("novo_produto", "editar_produto"):
            return TelaNovoProduto(self._area_conteudo, usuario= self.usuario_logado, on_navigate= nav, produto_id= extra)
        if destino=="entrada_manual":
            return TelaEntradaManual(self._area_conteudo, usuario= self.usuario_logado, on_navigate= nav, produto_id=extra)
        if destino=="importar_nfe":
            return TelaImportarNFe(self._area_conteudo,usuario=self.usuario_logado,on_navigate=nav)
        if destino=="entrada_danfe":
            return TelaEntradaDANFE(self._area_conteudo,usuario=self.usuario_logado,on_navigate=nav, produto_id=extra)
        if destino=="retirada":
            return TelaRetirada(self._area_conteudo,usuario=self.usuario_logado,on_navigate=nav)
        if destino=="baixa_vencido":
            return TelaRetirada(self._area_conteudo, usuario=self.usuario_logado, on_navigate=nav, baixa_vencido=True, lotes_vencidos=extra)
        if destino=="posicao":
            return TelaPosicaoEstoque(self._area_conteudo,usuario=self.usuario_logado,on_navigate=nav)
        if destino=="dashboard":
            return TelaDashboard(self._area_conteudo,usuario=self.usuario_logado,on_navigate=nav)
        if destino=="relatorios":
            return TelaCentralRelatorios(self._area_conteudo,usuario=self.usuario_logado,on_navigate=nav)
        if destino=="agendamento":
            return TelaAgendamento(self._area_conteudo,usuario= self.usuario_logado, on_navigate= nav)
        if destino=="estoque_minimo":
            return TelaEstoqueMinimo(self._area_conteudo, usuario=self.usuario_logado, on_navigate= nav)
        nomes = {
            "usuarios":       "Usuários — T-15",
            "gmail":          "Config. Gmail — T-17",
            "backup":         "Backup — T-18",
            "log":            "Log de Operações — T-19",
        }
        titulo = nomes.get(destino, destino)
        return TelaPlaceholder(self._area_conteudo, titulo=titulo)
    
    def _on_navigate_com_extra(self, destino: str, extra=None):
        """Versão do _navegar que aceita parâmetro extra(ex: produto_id)"""
        self.resetar_timer_sessao()
        for w in self._area_conteudo.winfo_children():
            w.destroy()
        tela= self._resolver_tela(destino, extra= extra)
        if tela:
            tela.pack(fill="both", expand= True)
    
    def destroy(self):
       self._scheduler.parar()
       super().destroy()

       
#---- Componentes da janela principal (titlebar, sidebar) --------------------------------------------------------------

class TitleBar(ctk.CTkFrame):
    """Barra de titulo superior- CP-01"""

    def __init__(self, master, usuario):
        super().__init__(master, fg_color=COR_AZUL, height=36, corner_radius=0)
        self.pack_propagate(False)
        
        ctk.CTkLabel(
            self, text= "Sistema de Controle de Estoque - Centro de Uro-nefrologia V1.0",
            text_color="white", font=ctk.CTkFont(size=14, weight="bold")
        ).pack(side="left", padx=8)

        #Informações do usuário e botão de logout
        frame_direita = ctk.CTkFrame(self, fg_color="transparent")
        frame_direita.pack(side="right", padx=12)


        hora= datetime.now().strftime("| %d/%m/%Y %H:%M")
        nome_perfil= f"({usuario.perfil.value.capitalize()}): {usuario.nome} "
        ctk.CTkLabel(                   
            frame_direita,
            text= f"{nome_perfil} . {hora}",
            text_color="white", font=ctk.CTkFont(size=11)
        ).pack(side="left")
    
class Sidebar(ctk.CTkFrame):
    """Menu lateral com itens por perfil - CP-02"""
    MENU= [
        ("__label__"        ,"Estoque",                       None),
        ("inicio"           ,"Início",                        ["tecnico", "adimin","ti"]),
        ("produtos"         ,"Produtos",                      ["ti", "tecnico", "admin"]),
        ("__label__"        ,"Movimentações",                 None),
        ("entrada_manual"   ,"Entrada Manual",                ["admin", "tecnico", "ti"]),
        ("importar_nfe"     ,"Importar NF-e",                 ["admin", "tecnico", "ti"]),
        ("entrada_danfe"    ,"Entrada DANFE",                 ["admin", "tecnico", "ti"]),
        ("retirada"         ,"Retirada",                      ["admin", "tecnico", "ti"]),
        ("__label__"        ,"Consulta",                      None),
        ("posicao"          ,"Posição de Estoque",            ["admin", "tecnico", "ti"]),
        ("dashboard"        ,"Dashboard",                     ["admin", "tecnico", "ti"]),
        ("__label__"        ,"Relatórios",                    None),
        ("relatorios"       ,"Gerar Relatórios",              ["admin", "ti"]),
        ("agendamento"      ,"Agendamento",                   ["ti"]),
        ("estoque_minimo"   ,"Estoque Mínimo" ,               ["admin", "ti"]),
        ("__label__"        ,"Configurações",                 None),
        ("usuarios"         ,"Gerenciamento de Usuários" ,    ["ti"]),
        ("gmail"            ,"Configurações Gmail" ,          ["ti"]),
        ("backup"           ,"Backup do Sistema" ,            ["ti"]),
        ("log"              ,"Log de Operações" ,             ["ti"]),
    ]

    def __init__(self, master, usuario, on_navigate, on_logout):
        super().__init__(master, fg_color=COR_SIDEBAR, width=200,corner_radius=0)
        self.pack_propagate(False)
        self._on_navigate = on_navigate
        self._usuario=usuario
        self._perfil = usuario.perfil.value
        self._botoes = {}
        self._ativo= None
        self._on_logout= on_logout
        self._construir()

    def _construir(self):
        nome_perfil= f" {self._usuario.nome} "
        usuario_perfil=f"{self._usuario.perfil.value.capitalize()}"
        frame_perfil=ctk.CTkFrame(self, fg_color="transparent")
        frame_perfil.pack(fill="x", padx=14,pady=(10,5), side="top")
        ctk.CTkLabel(                   
            frame_perfil,
            text= f"{nome_perfil}",
            text_color="white", font=ctk.CTkFont(size=16, weight="bold"),
            anchor="w"
        ).pack(anchor="w", pady=(0,2))

        badge_perfil=ctk.CTkFrame(frame_perfil, fg_color="#3A5B7C", 
                                  corner_radius=10)
        badge_perfil.pack(anchor="w")

        ctk.CTkLabel(badge_perfil, text=usuario_perfil,
                     text_color="#B3D4F0", font=ctk.CTkFont(size=11, weight="bold"),
                     anchor="w").pack(padx=10, pady=2)

        #linha separadora 
        ctk.CTkFrame(self, fg_color="#111111", height=1).pack(fill="x", padx=14, pady=(12, 10), side="top")

        #Menu de navegação
        self._menu_scroll = ctk.CTkScrollableFrame(
        self, 
        fg_color="transparent", 
        corner_radius=0,
        label_text="" 
        )
        self._menu_scroll.pack(fill="both", expand=True, side="top")

        label_pendente= None
        for item in self.MENU:
            destino, label, perfis = item

            if destino == "__label__":
                label_pendente=label    
                continue

            permitido= perfis and self._perfil in perfis
            if permitido:
                if label_pendente:
                    ctk.CTkLabel(
                        self._menu_scroll, 
                        text=label_pendente.upper(),
                        text_color="#7fa8cc",
                        font=ctk.CTkFont(size=9, weight="bold"),
                        anchor="w",
                    ).pack(fill="x", padx=14, pady=(10, 2))

                    label_pendente = None
                btn = ctk.CTkButton(
                    self._menu_scroll,
                    text=f"  {label}",
                    anchor="w",
                    fg_color="transparent",
                    text_color="white",
                    hover_color=COR_SIDEBAR_H,
                    height=32,
                    corner_radius=6,
                    font=ctk.CTkFont(size=12),
                    state="normal",
                    command=lambda d=destino: self._clicar(d)
                )
                btn.pack(fill="x", padx=6, pady=1)
                self._botoes[destino] = btn
        
        frame_rodape= ctk.CTkFrame(self, fg_color="transparent")
        frame_rodape.pack(fill="x", padx=14, pady=16, side="bottom")
        frame_rodape.grid_columnconfigure((0,1), weight=1)

        #botão troca senha
        btn_senha= ctk.CTkButton(frame_rodape, text="Trocar senha",
                                 fg_color="transparent", text_color="#888780", height=30, 
                                 font=ctk.CTkFont(size=11),
                                 command=lambda:self._on_navigate("troca_senha"))
        btn_senha.grid(row=0,column=0, padx=(0,4), sticky="ew")

        #botão sair 
        btn_sair= ctk.CTkButton(
            frame_rodape, text="Sair",width=50, height=24,
            fg_color="transparent",text_color="#888780",
            font=ctk.CTkFont(size=11, weight="bold"),command=self._on_logout
        )
        btn_sair.grid(row=0,column=1,padx=(4,0), sticky="ew")


 
    def _clicar(self, destino: str):
        # Remove destaque anterior 
        if self._ativo and self._ativo in self._botoes:
            self._botoes[self._ativo].configure(fg_color="transparent")
        # Destaca ativo
        self._ativo = destino
        self._botoes[destino].configure(fg_color=COR_SIDEBAR_A)
        self._on_navigate(destino)
